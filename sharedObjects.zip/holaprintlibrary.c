#include <stdio.h>

void print(char* cadena){
   printf("A shared library: %s\n", cadena);
}